package utilities;

import java.sql.*; // for Connection, DriverManager
import javax.swing.JOptionPane;

public class databaseConnection
{
	static Connection conn = null;
	public static boolean connFlag = false; //flag to test connection success
	static String dbURL, username, password;
	
	public static Connection establishConnection()
	{
		 try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jobdetails","root","");
            JOptionPane.showMessageDialog(null, "Connection Established");
            return conn;
            
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
        }
	public static boolean getConnFlag()
	{
		return connFlag;
	}
	
	public static void closeConnection() throws SQLException
	{
		conn.close();
	}
}
